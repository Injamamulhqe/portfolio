import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Portfolio from "./components/Portfolio";
import Blog from "./components/Blog";
import NewPost from "./components/NewPost";
import Contact from "./components/Contact";
import "./App.css";

function App() {
  const [page, setPage] = useState("home");
  const [blogPosts, setBlogPosts] = useState(
    JSON.parse(localStorage.getItem("blogPosts") || "[]")
  );

  const addPost = (post) => {
    const updated = [post, ...blogPosts];
    setBlogPosts(updated);
    localStorage.setItem("blogPosts", JSON.stringify(updated));
    setPage("blog");
  };

  return (
    <div>
      <Navbar setPage={setPage} page={page} />
      {page === "home" && <Home />}
      {page === "portfolio" && <Portfolio />}
      {page === "blog" && <Blog blogPosts={blogPosts} />}
      {page === "newpost" && <NewPost addPost={addPost} />}
      {page === "contact" && <Contact />}
    </div>
  );
}

export default App;