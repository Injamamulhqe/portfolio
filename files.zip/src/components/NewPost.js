import React, { useState } from "react";
import "./NewPost.css";

export default function NewPost({ addPost }) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !content) return;
    addPost({ title, content, date: new Date().toISOString() });
    setTitle("");
    setContent("");
  };
  return (
    <section className="new-post">
      <h2>New Blog Post</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Post Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          placeholder="Write your post..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
        ></textarea>
        <button type="submit">Add Post</button>
      </form>
    </section>
  );
}