import React from "react";
import projects from "../data/projects";
import "./Portfolio.css";

export default function Portfolio() {
  return (
    <section className="portfolio">
      <h2>My Projects</h2>
      <div className="project-list">
        {projects.map((p, i) => (
          <div className="project-card" key={i}>
            <h3>{p.title}</h3>
            <p>{p.desc}</p>
            {p.link && <a href={p.link} target="_blank" rel="noopener noreferrer">View</a>}
          </div>
        ))}
      </div>
    </section>
  );
}