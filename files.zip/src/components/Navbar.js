import React from "react";
import "./Navbar.css";

export default function Navbar({ setPage, page }) {
  return (
    <nav className="navbar">
      <div className="nav-brand" onClick={() => setPage("home")}>
        Injamamul Haque
      </div>
      <div className="nav-links">
        <button onClick={() => setPage("home")} className={page==="home" ? "active" : ""}>About</button>
        <button onClick={() => setPage("portfolio")} className={page==="portfolio" ? "active" : ""}>Portfolio</button>
        <button onClick={() => setPage("blog")} className={page==="blog" ? "active" : ""}>Blog</button>
        <button onClick={() => setPage("newpost")} className={page==="newpost" ? "active" : ""}>New Post</button>
        <button onClick={() => setPage("contact")} className={page==="contact" ? "active" : ""}>Contact</button>
      </div>
    </nav>
  );
}