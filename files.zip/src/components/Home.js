import React from "react";
import "./Home.css";

export default function Home() {
  return (
    <section className="home">
      <img
        src="https://avatars.githubusercontent.com/u/your-github-id?v=4"
        alt="Injamamul Haque"
        className="profile-pic"
      />
      <h1>Injamamul Haque</h1>
      <h2>
        Content Creator | Cinematographer | Music Producer | Web Developer
      </h2>
      <p>
        From Barpeta, Assam. BSc student at BBK College, Nagaon.
      </p>
      <div className="socials">
        <a href="https://instagram.com/injamamul.hqe" target="_blank" rel="noopener noreferrer">
          Instagram
        </a>
        <a href="https://x.com/injamamulhqe" target="_blank" rel="noopener noreferrer">
          X (Twitter)
        </a>
      </div>
    </section>
  );
}