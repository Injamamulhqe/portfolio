import React from "react";
import "./Contact.css";

export default function Contact() {
  return (
    <section className="contact">
      <h2>Contact Me</h2>
      <p>
        You can reach me on Instagram: <a href="https://instagram.com/injamamul.hqe" target="_blank" rel="noopener noreferrer">@injamamul.hqe</a>
      </p>
      <p>
        Or X (Twitter): <a href="https://x.com/injamamulhqe" target="_blank" rel="noopener noreferrer">@injamamulhqe</a>
      </p>
      <p>Barpeta, Assam, India</p>
    </section>
  );
}