import React from "react";
import "./Blog.css";

export default function Blog({ blogPosts }) {
  return (
    <section className="blog">
      <h2>Blog</h2>
      {blogPosts.length === 0 ? (
        <p>No posts yet. Click 'New Post' to add your first blog!</p>
      ) : (
        blogPosts.map((post, i) => (
          <div className="blog-post" key={i}>
            <h3>{post.title}</h3>
            <small>{new Date(post.date).toLocaleString()}</small>
            <p>{post.content}</p>
          </div>
        ))
      )}
    </section>
  );
}