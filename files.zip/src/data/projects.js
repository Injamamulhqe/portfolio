const projects = [
  {
    title: "My Photography Portfolio",
    desc: "A collection of my best cinematography and photography work.",
    link: "https://instagram.com/injamamul.hqe"
  },
  {
    title: "My Music Productions",
    desc: "Listen to my latest tracks and music compositions.",
    link: "#"
  },
  // Add more projects here
];

export default projects;